<?php



 
 echo "<img src ='qr_img.php?d=Terragon-Network'>";

?>

