<?php
// database credentials
define("DBHOST","localhost");			// this is how you make a CONSTANT in PHP
define("DBUSER","root");
define("DBPASS","root");
define("DBNAME","transit");
?>