	<footer class="text-center">
		&copy; <?php echo date("Y") ?> Lambton Transit <br>
	</footer>
  </body>
</html>