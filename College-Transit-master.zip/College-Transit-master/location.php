<?php include("header.php"); ?>

<div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">

          <a href="brampton.html" class="btn"> Click to view Brampton pick up location </a></br>
          <a href="mississauga.html" class="btn"> Click to view Mississauga pick up location </a>

         
        </div> <!--// col-12 -->
      </div> <!-- // column -->
    </div>

  

<?php include("footer.php"); ?>