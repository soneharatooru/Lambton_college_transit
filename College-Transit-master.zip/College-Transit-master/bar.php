 
    <a class="btn" href="notification.php" style="float:middle;">Notify Delay</a>

<!-- dropdown button group -->
<div class="dropdown" style="float:right;">
  <div class="btn-group">
    <a href="admin_schedule.php" class="btn">
      Welcome Admin
    </a>
    <a href="#" class="btn dropdown-toggle" tabindex="0">
      <i class="icon icon-caret"></i>
    </a>

    <!-- menu component -->
    <ul class="menu">
     	<a href="logout.php">LogOut</a>
    </ul>
  </div>
</div>